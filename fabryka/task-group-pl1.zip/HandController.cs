﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualReality
{
    enum HandednessType
    {
        Left, Right
    }

    abstract class HandController
    {
        protected HandednessType Handedness;

        public HandController(HandednessType Handedness)
        {
            this.Handedness = Handedness;
        }

        abstract public void Grab();

        abstract public bool IsHeld();

        abstract public void Vibrate();


    }
}
